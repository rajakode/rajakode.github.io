# bottom-sheet
Bottom sheet, implemented in pure HTML, CSS, and JavaScript
